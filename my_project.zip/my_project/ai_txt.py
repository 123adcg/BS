import json

from flask import Flask, render_template, request, session
from spider.zlbg import data_tq
from sql_data import input_excel_data
import pandas as pd
from spider.zlbg import data_tq
from analysis import zlbg_data
from analysis import job_data
import sql_data.sql as sql
from analysis import k1 as k

app = Flask(__name__)
app.secret_key = "my_secret_key"


# app.template_folder = './templates'
# app.static_folder = './static'


@app.route('/')
def index():
    return render_template('job_e_pay.html', data_edu=job_data.job_e_pay()[0], data_e1=job_data.job_e_pay()[3],
                           data_e2=job_data.job_e_pay()[4], data_ex1=job_data.job_e_pay()[5],
                           data_ex2=job_data.job_e_pay()[6])


@app.route('/zlbg_total')
def zlbg_total():
    return render_template('zlbg_total.html', year=zlbg_data.sql_table1()[0], num=zlbg_data.sql_table1()[1],
                           edu=zlbg_data.sql_table1()[2])


@app.route('/zlbg_table24')
def zlbg_table24():
    return render_template('zlbg_table24.html', label=zlbg_data.sql_table24()[0], data_lists=zlbg_data.sql_table24()[1],
                           signs=zlbg_data.sql_table24()[2], year=zlbg_data.sql_table1()[0],
                           num=zlbg_data.sql_table1()[1], edu=zlbg_data.sql_table1()[2])


@app.route('/xq_bar')
def xq_bar():
    return render_template('xq_bar.html', dq_data=job_data.job_map())


@app.route('/table_data')
def table_data():
    return render_template('table_data.html', list_data=job_data.data_sql()[0], clomuns=job_data.data_sql()[1],
                           le=job_data.data_sql()[2])


@app.route('/key_city_pay')
def key_city_pay():
    return render_template('key_city_pay.html', key_pays=job_data.key_count('杭州')[1],
                           key_nums=job_data.key_count('杭州')[0], nums=job_data.key_count('杭州')[2])


@app.route('/yc_index')
def yc_index():
    return render_template('yuce.html', result='模拟预测')


@app.route('/city_pay', methods=['POST'])
def city_pay():
    city = request.form['data']
    # 如果有表单提交，则将选中的值存储在 session 中
    if request.method == "POST":
        selected_value = request.form.get("data")
        session["selected_value"] = selected_value

    # 从 session 中读取选中的值
    selected_value = session.get("selected_value")
    return render_template('key_city_pay.html', key_pays=job_data.key_count(city)[1],
                           key_nums=job_data.key_count(city)[0], selected_value=selected_value,
                           nums=job_data.key_count(city)[2])


@app.route('/yc', methods=['POST'])
def yc():
    lst_ex = ['学历不限', '大专及以下', '大专', '本科', '硕士', '博士']
    dat = request.form.getlist('btn')

    data = dat[0].split(',')
    print(data)
    for item in data:
        if item in lst_ex:
            ex = lst_ex.index(item)
            data.remove(item)
            break
        else:
            ex = 3
    d = job_data.list_to_array(data, job_data.hash_data()[2])
    d.append(ex)
    print(d)
    return render_template('yuce.html', result=k.yuce(d))


if __name__ == "__main__":
    app.run(debug=True)
    sql.conn.close()
# Java、讲师 ['javascript', 'css', '前端开发', 'react', 'html'] D语言、R语言、C语言、C/C++  asp、c#、sql、jquery、数据库
