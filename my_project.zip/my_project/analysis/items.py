
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score


import job_data as job

data = job.hash_data()[0]
data1 = []
data2 =[]
for item in data:
    skills_index = len(item)-2
    item2 = item[len(item)-1]
    item  =  item[0:skills_index]
    data1.append(item)
    data2.append(item2)

label_len = job.hash_data()[1]

data1 = [' '.join(item) for item in data1]
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(data1)
y = data2

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 构建KNN模型
knn = KNeighborsClassifier(n_neighbors=label_len)
knn.fit(X_train, y_train)

# 预测测试集
y_pred = knn.predict(X_test)

# 输出准确率
accuracy = accuracy_score(y_test, y_pred)
print('准确率为：', accuracy)

