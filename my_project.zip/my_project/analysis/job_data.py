# -*- coding = utf-8 -*-
# @Time : 2023/4/18 22:32
# @Author :190808139 郑林
# @File : job_data.py
# @Software : PyCharm
import pandas as pd
import numpy as np
import sql_data.sql as sql

df = pd.read_sql_query("select * from job_liepin", sql.conn)
df2 = pd.read_sql_query("select * from job_liepin2", sql.conn)
df2 = df2.fillna(method='ffill')
# # 计算缺失值的数量
# num_missing = df2.isnull().sum().sum()
# 1189个
# print("DataFrame中共有{}个缺失值".format(num_missing))

def job_map():
    df_tq = df
    # 地区字符
    df_tq['job_location'] = df_tq['job_location'].apply(lambda x: x.split('-')[0] )
    # # 使用groupby方法将按照地区进行分组，并使用sum方法对每个地区的职位数量进行求和
    # grouped = df_tq.groupby('job_location')['count'].sum()
    # # 使用reset_index方法将分组后的结果转换成DataFrame，然后将location和count列重命名为name和value
    # result = grouped.reset_index(name='count').rename(columns={'job_location': 'name', 'count': 'value'})
    # # 将resultDataFrame转换为字典格式，方便传入Echarts绘制地图
    # dq_data_dict = result.to_dict(orient='list')
    location_count = df_tq['job_location'].value_counts().to_dict()
    dq_data = [{"name": k, "value": v} for k, v in location_count.items()]
    return dq_data
    # print(dq_data)

def data_sql():
    # 查询表中所有数据
    result = df.dropna()
    list_data = result.values.tolist()
    clomuns = ['名称', '公司', '业务方向', '公司人数','公司地点', '经验要求', '学历要求', '薪资', '技能要求', '详情链接']
    # print(len(clomuns))
    le = len(clomuns)
    return [list_data, clomuns, le]
# data_sql()

def item_to_index(item, list):
    if item in list:
        index = list.index(item)
        return index
    else:
        return -1
def re_list(list1):
    # 平均值
    mean_v = np.mean(list1)

    # 中位数
    med_v = np.median(list1)

    # 方差
    va_v = np.var(list1)

    # 标准差
    std_v = np.std(list1)

    # 最大值
    max_v = np.max(list1)

    # 最小值
    min_v = np.min(list1)

    # while len(list1) < 11:
    #     # round(sum(list1) / len(list1))
    #     list1.append(1)
    return [round(mean_v), round(med_v), round(va_v), round(std_v), round(max_v), round(min_v)]
def list_to_array(list1, list2):
    for i in range(0, len(list1)):
        if list1[i] in list2:
            index = list2.index(list1[i])
            list1[i] = index
        else:
            list1[i] = 0.5
    list1 = re_list(list1)
    return list1
def ex_tolist(list1):
    lst = ['学历不限', '大专及以下', '大专', '本科', '硕士', '博士']
    for item in list1:
        # '本科': 1762, '统招本科': 1224, '大专': 502, '硕士': 316, '本科及以上': 295, '学历不限': 210, '硕士及以上': 173, '博士': 75, '大专及以上': 44, '中专/中技': 6, '3个月': 2}
        if item == '中专/中技' or item == '3个月':
             return lst.index('大专及以下')
        elif item == '学历不限':
            return lst.index('学历不限')
        elif item == '大专及以上' or item == '大专':
             return lst.index('大专')
        elif item == '本科' or item == '本科及以上':
             return lst.index('本科')
        elif item == '硕士' or item == '硕士及以上':
             return lst.index('硕士')
        else:
            return lst.index('博士')

# k邻近数据
def hash_data():
    jobs_data = df2.dropna()
    jobs_skills = jobs_data['job_skills'].apply(lambda x: x.split('、')).tolist()
    jobs_key = jobs_data['key'].tolist()
    job_ex = jobs_data['job_education'].tolist()
    jobs_label = jobs_data['key'].unique().tolist()
    # print(jobs_label)
    skill_list = []
    for item in jobs_skills:
        for i in item:
            if i not in skill_list:
                skill_list.append(i)
    jobs_list = []
    label_len = len(jobs_label)
    for i in range(0, len(jobs_key)):
        jobs_key[i] = item_to_index(jobs_key[i], jobs_label)
        jobs_skills[i] = list_to_array(jobs_skills[i], skill_list)
        job_ex[i] = ex_tolist(job_ex[i])
        jobs_skills[i].append(job_ex[i])
        jobs_skills[i].append(jobs_key[i])
        jobs_list.append(jobs_skills[i])
        # print( jobs_skills[1000])
    return [jobs_list, label_len, skill_list]


# hash_data()

# def reutrn_list(list, num_list):

# 岗位学历和经验以及工资等数据
def job_e_pay():
    data_e_pay = df2.dropna()
    data_edu = data_e_pay['job_education'].value_counts().to_dict()
    edu = []
    for k, v in data_edu.items():
         edu.append([k, v])
    # 手动处理统计数据
    # '本科': 1762, '统招本科': 1224, '大专': 502, '硕士': 316, '本科及以上': 295, '学历不限': 210, '硕士及以上': 173, '博士': 75, '大专及以上': 44, '中专/中技': 6, '3个月': 2}
    e1 = ['学历不限', '大专及以下', '大专', '本科', '硕士', '博士']
    e2 = [210, 8, 546, 3281, 489, 75]

    data_ex = data_e_pay['job_experience'].value_counts().to_dict()
    ex = []
    # [[4, 1618], [8, 1254], [2, 864], [0, 719], [10, 154]]
    for k, v in data_ex.items():
        ex.append([k,v])
    ex_sorted = sorted(ex, key=lambda x: x[0])
    ex1 = [x[0] for x in ex_sorted]
    ex2 = [x[1] for x in ex_sorted]

    data_pay = data_e_pay[data_e_pay['job_pay'] != 0]['job_pay']
    pay1 = data_e_pay[(data_e_pay['job_pay'] < 10) & (data_e_pay['job_pay'] != 0)]['job_pay'].count()
    pay2 = data_e_pay[(data_e_pay['job_pay'] > 10) & (data_e_pay['job_pay'] <= 20)]['job_pay'].count()
    pay3 = data_e_pay[(data_e_pay['job_pay'] > 20) & (data_e_pay['job_pay'] <= 30)]['job_pay'].count()
    pay4 = data_e_pay[(data_e_pay['job_pay'] > 30) & (data_e_pay['job_pay'] <= 40)]['job_pay'].count()
    pay5 = data_e_pay[(data_e_pay['job_pay'] > 40) & (data_e_pay['job_pay'] <= 50)]['job_pay'].count()
    pay6 = data_e_pay[data_e_pay['job_pay'] > 50]['job_pay'].count()
    pay = [pay1, pay2, pay3, pay4, pay5, pay6]

    pay1_detail = data_e_pay[(data_e_pay['job_pay'] < 5) & (data_e_pay['job_pay'] > 0)]['job_pay'].count()
    pay2_detail = data_e_pay[(data_e_pay['job_pay'] > 5) & (data_e_pay['job_pay'] <= 8)]['job_pay'].count()
    pay3_detail = data_e_pay[(data_e_pay['job_pay'] > 8) & (data_e_pay['job_pay'] <= 12)]['job_pay'].count()
    pay4_detail = data_e_pay[(data_e_pay['job_pay'] > 12) & (data_e_pay['job_pay'] <= 18)]['job_pay'].count()
    # 小于2万的薪资详情统计
    p1 = [pay1_detail, pay2_detail, pay3_detail, pay4_detail]


    # 所有的工资详情统计
    p = []
    pay_count = data_pay.value_counts().to_dict()
    for k, v in pay_count.items():
         p.append([k, v])
    return [p, pay, p1, e1, e2, ex1, ex2]
    # print(ex2)

# 计算list平均值，去除最大最小
def my_avg(lst):
    if len(lst) != 0:
        max_i = max(lst)
        min_i = min(lst)
        new = [x for x in lst if x != max_i and x != min_i]
        avg = 0
        if len(new) != 0:
            avg = round(sum(new) / len(new), 1)
        return avg
    else:
        return 0
# 返回每个城市的每个岗位的平均薪资
def k_pay_avg(a, b):
    data_s = df2.dropna()
    avg_pay = data_s[(data_s['key'] == a) & (data_s['job_location'].str.contains(b))]['job_pay'].tolist()
    # print(avg_pay)
    avg = my_avg(avg_pay)
    return avg
def k_city_jobs(a, b):
    data_s = df2.dropna()
    nums = []
    for item in a:
        key_num = data_s[(data_s['key'] == item) & (data_s['job_location'].str.contains(b))]['key'].tolist()
        # print(avg_pay)
        num = len(key_num)
        nums.append(num)
    return nums
def key_count(city):
    data_s = df2.dropna()
    lst = ['软件', '数据', '运维', '前端', 'Java', '后端', '全栈', '图像', '测试', '硬件', '自然语言处理', '网络安全', '人工智能', '算法',
           '网络', 'UI', 'C#', 'Python', 'C++', 'Go', 'sql']
    # 每个岗位的数量
    jobs_num = []
    for k, v in data_s[data_s['key'].isin(lst)]['key'].value_counts().to_dict().items():
        if v:
            jobs_num.append(v)
    # 一个个城市的每个岗位的平均薪资
    k_avg_pay = []
    for key in lst:
        k_avg_pay.append(k_pay_avg(key, city))
    nums = k_city_jobs(lst, city)

    return [jobs_num, k_avg_pay, nums]
    # print(jobs_num)
# print(key_count('杭州')[2])
