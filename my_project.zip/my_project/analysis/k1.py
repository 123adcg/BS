# -*- coding = utf-8 -*-
# @Time : 2023/4/21 15:48
# @Author :190808139 郑林
# @File : k1.py
# @Software : PyCharm

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from analysis import job_data
from sklearn.feature_selection import SelectKBest, chi2



# 1. 导入数据
data = job_data.hash_data()[0]
# mode = stats.mode(d[:-1])[0][0]
# mean = np.mean(d[:-1])
# data = [mode, mean, d[-1]]

# print(len(data))
data = np.array(data)
# print(data[0:4])
# 2. 数据预处理
features = data[:, :-1]
label = data[:, -1]
scaler = StandardScaler()

num_samples = features.shape[0]

# 随机打乱样本数据的索引
indices = np.random.permutation(num_samples)

# 重新排列样本数据和对应的标签
features = features[indices]
label = label[indices]
# 特征选择
selector = SelectKBest(chi2, k=4)
X_new = selector.fit_transform(features, label)
# 3. 划分数据集
features = scaler.fit_transform(features)
X_train, X_test, y_train, y_test = train_test_split(features, label, test_size=0.2, random_state=0)

# 4. 训练模型
knn = KNeighborsClassifier(n_neighbors=3, metric='euclidean')
knn.fit(X_train, y_train)

# 5. 模型评估
y_pred = knn.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print('Accuracy:', accuracy)

# 6. 调整模型
# 尝试不同的k值和距离度量
def yuce(d):
    if d:
        # 7. 预测新数据
        new_data = [d]  # 示例新数据
        # new_data[0]= job_data.re_list(new_data[0])
        new_data = scaler.transform(new_data)
        predicted_label = knn.predict(new_data)
        keys = ['软件', '图像', '算法', '自然语言处理', '数据', '人工智能', '学习', '前端', '后端', '测试', '网络安全', '网络', '运维', 'UI', '区块链', '全栈', '硬件', 'Java', 'C++', 'PHP', 'C#', '.NET', 'Hadoop', 'Python', 'Ruby', 'Nodejs', 'Go', 'Delphi', 'sql']
        # print('Predicted Label:', keys[predicted_label[0]])
        str = '您目前具备的能力比较偏向' + (keys[predicted_label[0]])+'方向，本系统中有对此相关的一些信息，可前往数据可视化查看'
        return str
    else :
        return '请重新测试！！！'
