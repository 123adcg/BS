import pandas as pd
import sql_data.sql as sql

def tosting(s):
         str(s)
         return s

def sql_table1():
    # 处理zlbg第一个表需要的数据
    df = pd.read_sql_query("select * from table_1", sql.conn)

    # 获取每一列的有那些不同值
    year = df['届份'].unique().tolist()
    edu = df['学历层次'].unique().tolist()
    edu.pop()
    num = []
    # 列表解析
    years = [str(item) for item in year]
    # edu = [str(item) for item in edu]
    i = 0
    while i < 16:
        num.append(df.iloc[i, 1] + df.iloc[i, 2])
        i += 1
    num = [str(item) for item in num]
    return [years, num, edu]

def sql_table24():
    # 处理zlbg第二个表需要的数据
    tf = pd.read_sql_query("select * from table_24", sql.conn)

    signs = tf['就业标志'].unique().tolist()
    signs.pop()
    edu = ['研究生', '本科', '专科']
    year = tf['届份'].unique().tolist()
    year = [str(item) for item in year]
    year.reverse()
    year_edu = []
    for i in edu:
        for k in year:
            year_edu.append(k+i)
    i = 0
    # ，分组后的将每个series数组存在列表中
    lists = [[] for _ in range(3)]
    data_list = [[] for _ in range(12)]
    # while i < len(tf['就业标志']:
    # d1 = tf.iloc[0:14, 1]
    # 返回是是series（一个一维数组）
    a = tf.groupby('届份')['研究生']
    b = tf.groupby('届份')['本科生']
    c = tf.groupby('届份')['专科生']
    # key是2019-2022排序
    for key, value in a:
        lists[0].append(value)
    for key, value in b:
        lists[1].append(value)
    for key, value in c:
        lists[2].append(value)
    index = 0
    for i in range(3):
        for k in range(4):
            for value in lists[i][k]:
                data_list[index].append(value)
            index += 1


    for i in data_list:
        # 去除合计
        i.pop()
    data_list = [list(map(str, inner_lst)) for inner_lst in data_list]
    # signs.insert(0, '全不选')
    # signs.insert(0, '全选')
    return [year_edu, data_list, signs]
    # print(year_edu)

# sql_table24()