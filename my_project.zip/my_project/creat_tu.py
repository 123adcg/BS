# -*- coding = utf-8 -*-
# @Time : 2023/4/19 16:51
# @Author :190808139 郑林
# @File : creat_tu.py
# @Software : PyCharm
import json
from pyecharts import options as opts
from pyecharts.charts import Map
from analysis import job_data
from pyecharts import options as opts
from pyecharts.charts import Bar
from analysis import job_data
from pyecharts import options as opts
from pyecharts.charts import Bar

# 数据对象格式
data = job_data.job_map()

icon_path = 'static/images/computer.svg'
bar = (
    Bar()
    .add_xaxis([x['name'] for x in data])
    .add_yaxis(
        "",
        [x['value'] for x in data],
        label_opts=opts.LabelOpts(is_show=False),
        symbol='image://' + icon_path,
        symbol_size=[60, 40],
        symbol_position="end",
    )
    .set_global_opts(title_opts=opts.TitleOpts(title="象形柱图"))
)

bar.render("bar_chart.html")



