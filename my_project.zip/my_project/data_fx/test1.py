# -*- coding = utf-8 -*-
# @Time : 2023/4/5 19:26
# @Author :190808139 郑林
# @File : test1.py
# @Software : PyCharm

def t1():
