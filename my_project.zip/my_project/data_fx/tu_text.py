from flask import Flask, render_template
from pyecharts import options as opts
from pyecharts.charts import Bar
import pandas as pd

app = Flask(__name__)
app.template_folder = 'F:/my_project/templates'
app.static_folder = 'F:/my_project/static'

@app.route("/")
def index():
    # 呈现 HTML 模板文件
    return render_template("xq_bar.html")


if __name__ == "__main__":
    app.run(debug=True)
