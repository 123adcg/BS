from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium import webdriver
from bs4 import BeautifulSoup
import time  # 导包
import csv

# 猎聘爬去完成
data = []
def parsehtml(page_html):
    soup = BeautifulSoup(page_html, "lxml")
    job_list = soup.select(
        '#lp-search-job-box > div.content-wrap > section.content-left-section > div.job-list-box > div')
    # print(job_list)
    # 遍历每个职位信息节点，并获取所需的信息
    for job in job_list:
        # print(job)
        #     # 获取职位名称
        job_name = job.find('div', {'class': 'jsx-2693574896 ellipsis-1'}).get_text().strip()
        # 获取公司名称
        company_name = job.find('span', 'jsx-2693574896 company-name ellipsis-1').get_text().strip()
        # 获取公司性质
        try:
            company_sign = job.select('div.jsx-2693574896.company-tags-box.ellipsis-1 > span:nth-child(1)')[0].get_text().strip()
        except Exception as e:
            company_sign = '互联网'
            print(e)
        # 获取公司人数
        try:
            num_company = job.select('div.jsx-2693574896.company-tags-box.ellipsis-1 > span:last-child')[0].get_text().strip()
        except Exception as e:
            num_company = '0'
            print(e)
        # 获取工作地点
        job_location = job.find('span', 'jsx-2693574896 ellipsis-1').get_text().strip()
        # 获取经验要求
        job_education = job.select('div.jsx-2693574896.job-labels-box > span:nth-child(1)')[0].get_text().strip()
        # 获取学历要求
        job_experience = job.select('div.jsx-2693574896.job-labels-box > span:nth-child(2)')[0].get_text().strip()
        # 获取技能要求
        comment = job.select('div.jsx-2693574896.job-labels-box > span')
        job_skills = ''
        for i in range(2, len(comment)):
            if i != len(comment) - 1:
                job_skills += comment[i].get_text().strip() + '、'
            else:
                job_skills += comment[i].get_text().strip()
        # 获取薪资
        job_pay = job.select('div.jsx-2693574896.job-detail-header-box > span.jsx-2693574896.job-salary')[0].get_text().strip()
        # 获取详情连接
        job_detail = soup.select('div.jsx-2297469327.job-card-left-box > div > a')[0]['href'].strip()
        new_data = [job_name, company_name, company_sign, num_company, job_location, job_education, job_experience, job_pay, job_skills, job_detail]
        if new_data not in data:
            data.append(new_data)
def liepin_spider(key, data):
    page = 1
# 定义目标 URL 和搜索关键词
    url = 'https://www.liepin.com/'
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome'
                             '/111.0.0.0 Safari/537.36'}

    # 创建 Chrome 浏览器实例
    browser = webdriver.Chrome("C:\Program Files\Google\Chrome\Application\chromedriver.exe")

    # 访问目标页面
    browser.get(url)
    # browser.maximize_window()
    # time.sleep(60) # 让程序睡2秒
    wait = WebDriverWait(browser, 10)
    # 找到目标 li 标签
    input = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR,
                                                         '#home-search-bar-container > div > div > div > div > div > div:nth-child(1) > div.jsx-4146333934.search-input-container > div > div > div > input')))
    input.send_keys(key)

    btn = browser.find_element(By.CSS_SELECTOR,
                               '#home-search-bar-container > div > div > div > div > div > div:nth-child(1) > div.jsx-4146333934.search-input-container > div > div > div > span')
    btn.click()

    wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR,
                                                            '#lp-search-job-box > div.content-wrap > section.content-left-section > div.list-pagination-box > ul > li.ant-pagination-next > button')))

    # 直到加载出最后一个招聘信息
    wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR,
                                                        '#lp-search-job-box > div.content-wrap > section.content-left-section > div.job-list-box > div:nth-child(40)')))
    time.sleep(1)

    browser.find_elements(By.CSS_SELECTOR,
                                     '#lp-search-job-box > div.content-wrap > section.content-left-section > div.job-list-box > div')
    time.sleep(3)
    page_html = browser.page_source
    parsehtml(page_html)
    # print(page_html)
    for i in range(1,5):
        page += 1
        next_page_btn = browser.find_elements(By.CSS_SELECTOR,'#lp-search-job-box > div.content-wrap > section.content-left-section > div.list-pagination-box > ul > li.ant-pagination-next > button')[0]
        next_page_btn.click()
        wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR,
                                                     '#lp-search-job-box > div.content-wrap > section.content-left-section > div.job-list-box > div:nth-child(40)')))
        page_html = browser.page_source
        parsehtml(page_html)
        time.sleep(5)
    browser.quit()
def save_data(data):
    with open('data_1.csv', 'a', encoding='utf-8', errors='ignore', newline='') as csvfile:
        writer = csv.writer(csvfile)
        for row in data:
            writer.writerow(row)
def main():
    lst = ['软件', '图像', '自然语言处理', '人工智能', '学习', '前端', '后端', '数据', '算法', '测试', '网络安全', '运维', 'UI', '区块链', '网络', '全栈',
           '硬件', 'Java', 'C++', 'PHP', 'C#', '.NET', 'Hadoop', 'Python', 'Perl', 'Ruby', 'Nodejs', 'Go', 'Javascript',
           'Delphi', 'jsp', 'sql']
    for key in lst:
            liepin_spider(key, data)
            time.sleep(10)
    save_data(data)


if __name__ == "__main__":
    main()