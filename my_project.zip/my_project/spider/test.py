from bs4 import BeautifulSoup
from analysis import job_data
a = job_data.hash_data()[2]
# 产业互联网、框架开发、框架设计、架构设计、PHP、MySQL、Unix、Linux、SVN、GIT
b = ['PHP', 'MySQL', '后端开发', 'SQL']
d = job_data.list_to_array(b,a)
print(len(d), d)


# prin
# t(d)