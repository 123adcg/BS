# -*- coding = utf-8 -*-
# @Time : 2023/4/3 15:13
# @Author :190808139 郑林
# @File : data_tq.py
# @Software : PyCharm
# -*- coding = utf-8 -*-
# @Time : 2023/3/29 19:56
# @Author :190808139 郑林
# @File : test.py
# @Software : PyCharm
# 将pdf的表格数据提取保存在excel中

# 导入必要的库
import pdfplumber
import pandas as pd
import os

# 提取pdf数据转存在excel中
def data_tq(path, name):
        with pdfplumber.open(path) as pdf:
            # 提取每一页中的表格数据
            pages = pdf.pages
            tables = []
            for page in pages:
                tbls = page.extract_tables()
                tables.extend(tbls)
        # 将表格转换为数据框，并将数据框写入Excel文件
        try:
            with pd.ExcelWriter("F:/my_project/data_excel/" + name + ".xlsx") as writer:
                for i, table in enumerate(tables):
                    table_name = f"Table_{i + 1}"
                    df = pd.DataFrame(table[1:], columns=[str(x) for x in table[0]])
                    # print(df)
                    df.to_excel(writer, sheet_name=table_name, index=False)
                    writer.sheets[table_name].name = f"{table_name}"
        except Exception as e:
            print(f"111Error processing file {name}: {e}")
            raise e
def main():
    # 定义要遍历的文件夹路径
    folder_path = r"F:/my_project/data_pdf"
    # 遍历文件夹中的所有文件
    for file_name in os.listdir(folder_path):
            # print(type(os.path.splitext(file_name)[0]))
            # 确保文件是PDF格式
        if file_name.endswith(".pdf"):
            name = os.path.splitext(file_name)[0]
            try:
                data_tq(os.path.join(folder_path, file_name), str(name))
            except TypeError as e:
                print(f"222Error processing file {file_name}: {e}")






