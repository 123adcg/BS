# -*- coding = utf-8 -*-
# @Time : 2023/3/29 15:39
# @Author :190808139 郑林
# @File : zhilianbaogao.py
# @Software : PyCharm

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
# 就业质量报告爬虫完成
from selenium import webdriver
from bs4 import BeautifulSoup
import requests

def down_load_pdf(url):
    try:
        response = requests.get(url)
    except requests.exceptions.ConnectionError as e:
        print(e)
        return
    html = BeautifulSoup(response.text, 'html.parser')
    # 找到“专题专栏”中的链接
    # 找到第一个tbody元素
    tbody = html.find('tbody')
    # 找到tbody元素下的第一个td元素
    first_td = tbody.find('td')
    text = first_td.text.strip() # 获取td中的文本文字并去除首尾空格和换行符
    # print(text)
    # 找到td元素中的第一个a标签
    link = first_td.find('a')
    if '报告' in text:
            report_url = "http://www.ejobmart.cn" + link["href"]
            # 访问报告链接并下载
            try:
                response = requests.get(report_url)
            except requests.exceptions.ConnectionError as e:
                print(e)
                print('下载这里的问题')
                return
            with open('F:/my_project/data_pdf/' + text + '.pdf', 'wb') as f:
                f.write(response.content)
def main():
    url = "http://www.ejobmart.cn/jyxt-v5/jyweb/webIndex.zf"

    # 创建 Chrome 浏览器实例
    browser = webdriver.Chrome("C:\Program Files\Google\Chrome\Application\chromedriver.exe")

    # 访问目标页面
    browser.get(url)

    # 找到目标 li 标签
    li = browser.find_element_by_css_selector("#navlist > li:nth-child(10)")

    # 修改li标签的属性，让下面的a标签显示出来
    oldClass = li.get_attribute("class")
    newClass = oldClass.replace(oldClass, "dropdown open")
    # 对属性进行编辑并将其更新回原始元素，以实现标签属性的编辑。
    browser.execute_script("arguments[0].setAttribute('class', arguments[1])", li, newClass)
    # # 模拟鼠标放在 li 标签上
    # ActionChains(browser).move_to_element(li).perform()

    # 找到目标 a 标签
    a = li.find_element_by_css_selector("#navlist > li:nth-child(10) > ul > li:nth-child(6) > a")

    # 点击 a 标签，打开就业质量报告页面
    a.click()
    wait = WebDriverWait(browser, 10)
    element = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "#newsListBox > div.list-ctn.bg-w > ul > li")))
    # 获取报告页面的 HTML 内容
    soup = BeautifulSoup(browser.page_source, "html.parser")
    # 关闭浏览器驱动
    browser.quit()
    # 找到“专题专栏”中的链接
    li_list = soup.select("#newsListBox > div.list-ctn.bg-w > ul > li")
    # 自定义下载pdf文件函数
    for li in li_list:
        a = li.find("a")
        a_url = "http://www.ejobmart.cn" + a.get("href")
        # print(a.get("href"), a.text)
        down_load_pdf(a_url)

    # 2016没有总体报告，且和2017年一样，dns无法访问。