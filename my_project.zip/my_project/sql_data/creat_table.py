# -*- coding = utf-8 -*-
# @Time : 2023/4/15 17:36
# @Author :190808139 郑林
# @File : creat_table.py
# @Software : PyCharm
import sql_data.sql as sql
def main():
    # 如果存在就不创建
    for t_name in ['table_1', 'table_24', 'job_liepin']:
        sql.cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name={}".format(t_name))
        # 获取查询结果
        result = sql.cursor.fetchone()
        # 判断是否存在名为“job”的表
        if result:
            pass
        else:
            if t_name == 'table_1':
                sql1 = f'''
                                CREATE TABLE table_1 (
                                            学历层次 TEXT,
                                            男性 INTEGER,
                                            女性 INTEGER,
                                            计算机 INTEGER,
                                            占比 TEXT,
                                            届份 INTEGER  
                                        );
                            '''
                sql.cursor.execute(sql1)
                sql.conn.commit()
            elif t_name == 'table_24':
                sql2 = f'''
                                CREATE TABLE table_24 (
                                        就业标志 TEXT,
                                        研究生 INTEGER,
                                        本科生 INTEGER,
                                        专科生 INTEGER,
                                        合计 INTEGER,
                                        男生 TEXT ,
                                        女生 TEXT ,
                                        届份 INTEGER 
                                    );
                            '''
                sql.cursor.execute(sql2)
                sql.conn.commit()
            else:
                sql3 = '''
                               CREATE TABLE job_liepin (
                                   job_name TEXT,
                                   company_name TEXT,
                                   company_sign TEXT,
                                   num_company INTEGER,
                                   job_location TEXT,
                                   job_experience INTEGER,
                                   job_education TEXT,
                                   job_pay INTEGER,
                                   job_skills TEXT,
                                   job_detail TEXT
                               );
                       '''

                sql.cursor.execute(sql3)
                sql.conn.commit()







            # 关闭数据库连接

            # sql.cursor.execute('DROP TABLE IF EXISTS {}; '.format(t_name))


