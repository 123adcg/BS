# -*- coding = utf-8 -*-
# @Time : 2023/4/10 13:53
# @Author :190808139 郑林
# @File : input_excel_data.py
# @Software : PyCharm
import sqlite3
import sql_data.sql as sql
import pandas as pd
import os
import re

def add_year(path, year):
    df1 = pd.read_excel(path, sheet_name="Table_1", engine='openpyxl')
    df2 = pd.read_excel(path, sheet_name="Table_3", engine='openpyxl')
    df3 = pd.read_excel(path, sheet_name="Table_4", engine='openpyxl')
    if year in ['2019', '2022']:
        df4 = pd.read_excel(path, sheet_name="Table_24", engine='openpyxl')

    else:
        df4 = pd.read_excel(path, sheet_name="Table_25", engine='openpyxl')
    # 添加新列，将小计替换成计算机
    df1.rename(columns={'小计': '计算机'}, inplace=True)
    # 将博士生和硕士生合并为研究生
    df1.loc[0] = ['研究生', df1.iloc[0, 1] + df1.iloc[1, 1],
                  df1.iloc[0, 2] + df1.iloc[1, 2],
                  df1.iloc[0, 3] + df1.iloc[1, 3],
                  float(re.search(r'\d+\.\d+', df1.iloc[0, 4]).group()) + float(
                      re.search(r'\d+\.\d+', df1.iloc[1, 4]).group())]
    df1.drop(1, inplace=True)
    # 20,21,在table_25,table3、4有问题(22也是)
    # 19、22在table_24
    d2 = int(df2.iloc[8, 1])
    d3 = int(df2.iloc[8, 3])
    if year in ['2019', '2020']:
        d4 = int(df3.iloc[3, 1])
    else:
        d4 = int(df3.iloc[1, 1])
    d5 = d2 + d3 + d4
    df1['计算机'] = [d2, d3, d4, d5]
    df1['届份'] = year
    df4['届份'] = year
    df4.rename(columns={'男女比例': '男生', 'None': '女生'}, inplace=True)
    if year in ['2021', '2022']:
        df4.rename(columns={'本科': '本科生', '专科（高职）': '专科生', '专科（高职）生': '专科生'}, inplace=True)

    df4.drop(0, inplace=True)
    # print(df3)
    return [df1, df4]

def input_zlbg(path, name):
    year = re.findall(r'\d+', name)[0]
    # print(path)
    df1, df4 = add_year(path, year)
    print(df1)
    print('---------------------/n')
    print(df4)
    print('........................../n')
    try:
        df1.to_sql('table_1', sql.conn, if_exists='append', index=False)
        df4.to_sql('table_24', sql.conn, if_exists='append', index=False)
        # data = sql.cursor.fetchall()
        # print(data)
    except Exception as e:
        print(f"sql sqlError processing: {e}")
        raise e
def db_excel():
    # 定义要遍历的文件夹路径
    folder_path = r"F:/my_project/data_excel"
    # 遍历文件夹中的所有文件
    for file_name in os.listdir(folder_path):
        name = os.path.splitext(file_name)[0]
        input_zlbg(os.path.join(folder_path, file_name), str(name))
# db_excel()
def tq_table():
    # 提取table其他信息
    pass