import sql_data.sql as sql
import pandas as pd
import re


# 提取字段的数字，用均值替代
def mid_data(a):
    if 'k' in a:
        str = re.findall(r'\d+', a)
        s = []
        for num in str:
            s.append(int(num))
        if len(s) == 2:
            mean = int(round(sum(s) / len(s)))
        elif len(s) == 3:
            # 处理薪资字段，有的是13、15、18薪资
            mean = int((s[0] + s[1])/2 * s[2] / 12)
        elif len(s) == 1:
            mean = s[0]
        else:
            mean = 0
        return mean
    elif '元' in a:
        str = re.findall(r'\d+', a)
        s = []
        for num in str:
            s.append(int(num) * 0.024)
        if len(s) == 2:
            mean = round(sum(s) / len(s), 2)
        elif len(s) == 1:
            # 处理薪资字段，有的是13、15、18薪资
            mean = round(s[0], 2)
        elif len(s) == 1:
            mean = 0
        else:
            mean = 0
        return mean
    else :
        str = re.findall(r'\d+', a)
        s = []
        for num in str:
            s.append(int(num))
        if len(s) == 2:
            mean = int(round(sum(s) / len(s)))
        elif len(s) == 3:
            # 处理薪资字段，有的是13、15、18薪资
            mean = int((s[0] + s[1]) / 2 * s[2] / 12)
        elif len(s) == 1:
            mean = s[0]
        else:
            mean = 0
        return mean
def job_lebie(s):
    lst = ['软件', '图像', '自然语言处理', '人工智能', '学习', '前端', '后端', '数据', '算法', '测试', '网络安全', '运维', 'UI', '区块链', '网络', '全栈',
           '硬件', 'Java', 'C++', 'PHP', 'C#', '.NET', 'Hadoop', 'Python', 'Perl', 'Ruby', 'Nodejs', 'Go', 'Javascript',
           'Delphi', 'jsp', 'sql']
    for item in lst:
        if item in s:
            return item
            break

def td_jobdata():
    # 读取jobs数据
    df = pd.read_csv('../spider/data_1.csv', header=0)
    df['num_company'] = df['num_company'].apply(mid_data)
    df['job_experience'] = df['job_experience'].apply(mid_data)
    df['job_pay'] = df['job_pay'].apply(mid_data)
    df['key'] = df['job_name'].apply(job_lebie)
    df.to_sql('job_liepin2', sql.conn, if_exists='append', index=False)
    # print( df.head(2)['job_pay'])

td_jobdata()