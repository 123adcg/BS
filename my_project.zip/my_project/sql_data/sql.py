# -*- coding = utf-8 -*-
# @Time : 2023/4/10 13:54
# @Author :190808139 郑林
# @File : sql.py
# @Software : PyCharm
import sqlite3

global conn
conn = sqlite3.connect('F:/my_project/sql_data/my.db', timeout=10, check_same_thread=False)
cursor = conn.cursor()



