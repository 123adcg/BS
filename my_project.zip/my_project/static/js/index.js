//        var buttons = document.querySelectorAll(".dropdown-content button");
//		var content = document.getElementsByClassName("content")[0];
//
//		buttons.forEach(function(button) {
//			button.addEventListener("click", function() {
//				content.innerHTML = `<h1>${button.textContent}</h1><p>${button.textContent}</p>`;
//			});
//		});
//		var dropbtn = document.querySelector(".dropbtn");
//		var dropdownContent = document.querySelector(".dropdown-content");
//		var button5 = document.querySelector(".button5");
//
//		dropbtn.addEventListener("mouseenter", function() {
//		    button5.style.display = "none";
//		});
//
//		dropbtn.addEventListener("mouseleave", function() {
//		    if (!dropdownContent.matches(":hover")) {
//		        button5.style.display = "flex";
//		    }
//		});
//
//		dropdownContent.addEventListener("mouseleave", function() {
//		    button5.style.display = "flex";
//		});
////		button5.addEventListener("click", function() {
////				content.innerHTML = `<h1>${button5.textContent}</h1><p>${button5.textContent}</p>`;
////			});